#include <igloo/igloo.h>

using namespace igloo;

Context(TODO){
    /*
        your test cases here
    */
};

int main(int argc, const char* argv[]){
    return TestRunner::RunAllTests(argc, argv);
}
